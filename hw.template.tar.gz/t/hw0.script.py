import numpy as np
a = [[1, 0], [0, 1]]
b = [[4, 1], [2, 2]]
print np.dot(a, b)
print np.cross(a, b)
