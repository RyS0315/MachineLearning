from PIL import Image
import os
import re
from glob import glob

for filename in os.listdir('.'):
  if filename.endswith('png'):
    im = Image.open(filename).convert('L')
    width, height = im.size
    cw = round(width/2)
    ch = round(height/2)
    im = im.crop((cw-922, ch-754, cw+922, ch+754))
    im.save(filename[:-4] + "_g.png")

